# Cricket Bat detection > 2024-04-24 7:33pm
https://universe.roboflow.com/cricketbatting-kvxyo/cricket-bat-detection

Provided by a Roboflow user
License: Public Domain

